This dlls for OpenMP-suport and for netCDF Support are for 64bit-Windows. 
Please copy them to the directory, the wasim-executables are loacted in. 
Or install 
- the MS Visual Studio 2012 redistributables which does contain 32bit and 64bit 
  versions of the vcomp120.dll 
- the latest netCDF-redistributables (search for netCDF download and choose your system)

Under Linux, packages for netCDF and openMP are available and required as well, 
but with differing names for each distribution, so please refer to the model development 
details on the wasim home page and look for the comments to version 10.02.02
(http://www.wasim.ch/de/the_model/dev_details.htm)

May 24, 2018,
J Schulla
